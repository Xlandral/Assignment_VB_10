﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FreeStyleMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FreeStyleMain))
        Me.btnMixDis = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.btnStat = New System.Windows.Forms.Button()
        Me.btnReOrder = New System.Windows.Forms.Button()
        Me.btnSyrupLvl = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.CocaCola = New System.Windows.Forms.PictureBox()
        Me.CokeCherry = New System.Windows.Forms.PictureBox()
        Me.CokeCherryVanilla = New System.Windows.Forms.PictureBox()
        Me.CokeLemon = New System.Windows.Forms.PictureBox()
        Me.CokeLime = New System.Windows.Forms.PictureBox()
        Me.CokeOrange = New System.Windows.Forms.PictureBox()
        Me.CokeOrangeVanilla = New System.Windows.Forms.PictureBox()
        Me.CokeRaspberry = New System.Windows.Forms.PictureBox()
        Me.CokeVanilla = New System.Windows.Forms.PictureBox()
        Me.CokeCremeSoda = New System.Windows.Forms.PictureBox()
        Me.Small = New System.Windows.Forms.Label()
        Me.Large = New System.Windows.Forms.Label()
        Me.Medium = New System.Windows.Forms.Label()
        Me.ExtraLarge = New System.Windows.Forms.Label()
        Me.btnMainMenu = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CocaCola, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeCherry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeCherryVanilla, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeLemon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeLime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeOrange, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeOrangeVanilla, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeRaspberry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeVanilla, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeCremeSoda, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnMixDis
        '
        Me.btnMixDis.Location = New System.Drawing.Point(579, 67)
        Me.btnMixDis.Name = "btnMixDis"
        Me.btnMixDis.Size = New System.Drawing.Size(123, 40)
        Me.btnMixDis.TabIndex = 1
        Me.btnMixDis.Text = "Mix/&Dispense"
        Me.btnMixDis.UseVisualStyleBackColor = True
        '
        'btnReports
        '
        Me.btnReports.Location = New System.Drawing.Point(579, 113)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Size = New System.Drawing.Size(123, 40)
        Me.btnReports.TabIndex = 2
        Me.btnReports.Text = "&Reports"
        Me.btnReports.UseVisualStyleBackColor = True
        '
        'btnStat
        '
        Me.btnStat.Location = New System.Drawing.Point(579, 159)
        Me.btnStat.Name = "btnStat"
        Me.btnStat.Size = New System.Drawing.Size(123, 40)
        Me.btnStat.TabIndex = 3
        Me.btnStat.Text = "&Statistic"
        Me.btnStat.UseVisualStyleBackColor = True
        '
        'btnReOrder
        '
        Me.btnReOrder.Location = New System.Drawing.Point(579, 205)
        Me.btnReOrder.Name = "btnReOrder"
        Me.btnReOrder.Size = New System.Drawing.Size(123, 40)
        Me.btnReOrder.TabIndex = 4
        Me.btnReOrder.Text = "Re-&Order Syrup"
        Me.btnReOrder.UseVisualStyleBackColor = True
        '
        'btnSyrupLvl
        '
        Me.btnSyrupLvl.Location = New System.Drawing.Point(579, 251)
        Me.btnSyrupLvl.Name = "btnSyrupLvl"
        Me.btnSyrupLvl.Size = New System.Drawing.Size(123, 40)
        Me.btnSyrupLvl.TabIndex = 5
        Me.btnSyrupLvl.Text = "&Syrup Level"
        Me.btnSyrupLvl.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(207, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(203, 95)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 25
        Me.PictureBox1.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(579, 339)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(123, 40)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'CocaCola
        '
        Me.CocaCola.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CocaCola.Image = CType(resources.GetObject("CocaCola.Image"), System.Drawing.Image)
        Me.CocaCola.Location = New System.Drawing.Point(24, 104)
        Me.CocaCola.Name = "CocaCola"
        Me.CocaCola.Size = New System.Drawing.Size(105, 95)
        Me.CocaCola.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CocaCola.TabIndex = 28
        Me.CocaCola.TabStop = False
        '
        'CokeCherry
        '
        Me.CokeCherry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeCherry.Image = CType(resources.GetObject("CokeCherry.Image"), System.Drawing.Image)
        Me.CokeCherry.Location = New System.Drawing.Point(246, 104)
        Me.CokeCherry.Name = "CokeCherry"
        Me.CokeCherry.Size = New System.Drawing.Size(105, 95)
        Me.CokeCherry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeCherry.TabIndex = 29
        Me.CokeCherry.TabStop = False
        '
        'CokeCherryVanilla
        '
        Me.CokeCherryVanilla.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeCherryVanilla.Image = CType(resources.GetObject("CokeCherryVanilla.Image"), System.Drawing.Image)
        Me.CokeCherryVanilla.Location = New System.Drawing.Point(246, 242)
        Me.CokeCherryVanilla.Name = "CokeCherryVanilla"
        Me.CokeCherryVanilla.Size = New System.Drawing.Size(105, 95)
        Me.CokeCherryVanilla.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeCherryVanilla.TabIndex = 30
        Me.CokeCherryVanilla.TabStop = False
        '
        'CokeLemon
        '
        Me.CokeLemon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeLemon.Image = CType(resources.GetObject("CokeLemon.Image"), System.Drawing.Image)
        Me.CokeLemon.Location = New System.Drawing.Point(135, 104)
        Me.CokeLemon.Name = "CokeLemon"
        Me.CokeLemon.Size = New System.Drawing.Size(105, 95)
        Me.CokeLemon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeLemon.TabIndex = 31
        Me.CokeLemon.TabStop = False
        '
        'CokeLime
        '
        Me.CokeLime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeLime.Image = CType(resources.GetObject("CokeLime.Image"), System.Drawing.Image)
        Me.CokeLime.Location = New System.Drawing.Point(357, 104)
        Me.CokeLime.Name = "CokeLime"
        Me.CokeLime.Size = New System.Drawing.Size(105, 95)
        Me.CokeLime.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeLime.TabIndex = 32
        Me.CokeLime.TabStop = False
        '
        'CokeOrange
        '
        Me.CokeOrange.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeOrange.Image = CType(resources.GetObject("CokeOrange.Image"), System.Drawing.Image)
        Me.CokeOrange.Location = New System.Drawing.Point(24, 242)
        Me.CokeOrange.Name = "CokeOrange"
        Me.CokeOrange.Size = New System.Drawing.Size(105, 95)
        Me.CokeOrange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeOrange.TabIndex = 33
        Me.CokeOrange.TabStop = False
        '
        'CokeOrangeVanilla
        '
        Me.CokeOrangeVanilla.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeOrangeVanilla.Image = CType(resources.GetObject("CokeOrangeVanilla.Image"), System.Drawing.Image)
        Me.CokeOrangeVanilla.Location = New System.Drawing.Point(135, 242)
        Me.CokeOrangeVanilla.Name = "CokeOrangeVanilla"
        Me.CokeOrangeVanilla.Size = New System.Drawing.Size(105, 95)
        Me.CokeOrangeVanilla.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeOrangeVanilla.TabIndex = 34
        Me.CokeOrangeVanilla.TabStop = False
        '
        'CokeRaspberry
        '
        Me.CokeRaspberry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeRaspberry.Image = CType(resources.GetObject("CokeRaspberry.Image"), System.Drawing.Image)
        Me.CokeRaspberry.Location = New System.Drawing.Point(357, 242)
        Me.CokeRaspberry.Name = "CokeRaspberry"
        Me.CokeRaspberry.Size = New System.Drawing.Size(105, 95)
        Me.CokeRaspberry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeRaspberry.TabIndex = 35
        Me.CokeRaspberry.TabStop = False
        '
        'CokeVanilla
        '
        Me.CokeVanilla.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeVanilla.Image = CType(resources.GetObject("CokeVanilla.Image"), System.Drawing.Image)
        Me.CokeVanilla.Location = New System.Drawing.Point(468, 242)
        Me.CokeVanilla.Name = "CokeVanilla"
        Me.CokeVanilla.Size = New System.Drawing.Size(105, 95)
        Me.CokeVanilla.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeVanilla.TabIndex = 36
        Me.CokeVanilla.TabStop = False
        '
        'CokeCremeSoda
        '
        Me.CokeCremeSoda.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CokeCremeSoda.Image = CType(resources.GetObject("CokeCremeSoda.Image"), System.Drawing.Image)
        Me.CokeCremeSoda.Location = New System.Drawing.Point(468, 104)
        Me.CokeCremeSoda.Name = "CokeCremeSoda"
        Me.CokeCremeSoda.Size = New System.Drawing.Size(105, 95)
        Me.CokeCremeSoda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeCremeSoda.TabIndex = 37
        Me.CokeCremeSoda.TabStop = False
        '
        'Small
        '
        Me.Small.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Small.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Small.Location = New System.Drawing.Point(98, 369)
        Me.Small.Name = "Small"
        Me.Small.Size = New System.Drawing.Size(66, 25)
        Me.Small.TabIndex = 39
        Me.Small.Text = "8oz"
        '
        'Large
        '
        Me.Large.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Large.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Large.Location = New System.Drawing.Point(318, 369)
        Me.Large.Name = "Large"
        Me.Large.Size = New System.Drawing.Size(66, 25)
        Me.Large.TabIndex = 40
        Me.Large.Text = "24oz"
        '
        'Medium
        '
        Me.Medium.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Medium.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Medium.Location = New System.Drawing.Point(207, 369)
        Me.Medium.Name = "Medium"
        Me.Medium.Size = New System.Drawing.Size(66, 25)
        Me.Medium.TabIndex = 41
        Me.Medium.Text = "16oz"
        '
        'ExtraLarge
        '
        Me.ExtraLarge.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ExtraLarge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ExtraLarge.Location = New System.Drawing.Point(435, 369)
        Me.ExtraLarge.Name = "ExtraLarge"
        Me.ExtraLarge.Size = New System.Drawing.Size(66, 25)
        Me.ExtraLarge.TabIndex = 42
        Me.ExtraLarge.Text = "32oz"
        '
        'btnMainMenu
        '
        Me.btnMainMenu.Location = New System.Drawing.Point(579, 297)
        Me.btnMainMenu.Name = "btnMainMenu"
        Me.btnMainMenu.Size = New System.Drawing.Size(123, 40)
        Me.btnMainMenu.TabIndex = 6
        Me.btnMainMenu.Text = "R&eset"
        Me.btnMainMenu.UseVisualStyleBackColor = True
        '
        'FreeStyleMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(716, 428)
        Me.Controls.Add(Me.ExtraLarge)
        Me.Controls.Add(Me.Medium)
        Me.Controls.Add(Me.Large)
        Me.Controls.Add(Me.Small)
        Me.Controls.Add(Me.CokeCremeSoda)
        Me.Controls.Add(Me.CokeVanilla)
        Me.Controls.Add(Me.CokeRaspberry)
        Me.Controls.Add(Me.CokeOrangeVanilla)
        Me.Controls.Add(Me.CokeOrange)
        Me.Controls.Add(Me.CokeLime)
        Me.Controls.Add(Me.CokeLemon)
        Me.Controls.Add(Me.CokeCherryVanilla)
        Me.Controls.Add(Me.CokeCherry)
        Me.Controls.Add(Me.CocaCola)
        Me.Controls.Add(Me.btnMainMenu)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnSyrupLvl)
        Me.Controls.Add(Me.btnReOrder)
        Me.Controls.Add(Me.btnStat)
        Me.Controls.Add(Me.btnReports)
        Me.Controls.Add(Me.btnMixDis)
        Me.Name = "FreeStyleMain"
        Me.Text = "Freestyle Coca-Cola Machine"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CocaCola, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeCherry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeCherryVanilla, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeLemon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeLime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeOrange, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeOrangeVanilla, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeRaspberry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeVanilla, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeCremeSoda, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnMixDis As Button
    Friend WithEvents btnReports As Button
    Friend WithEvents btnStat As Button
    Friend WithEvents btnReOrder As Button
    Friend WithEvents btnSyrupLvl As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents CocaCola As PictureBox
    Friend WithEvents CokeCherry As PictureBox
    Friend WithEvents CokeCherryVanilla As PictureBox
    Friend WithEvents CokeLemon As PictureBox
    Friend WithEvents CokeLime As PictureBox
    Friend WithEvents CokeOrange As PictureBox
    Friend WithEvents CokeOrangeVanilla As PictureBox
    Friend WithEvents CokeRaspberry As PictureBox
    Friend WithEvents CokeVanilla As PictureBox
    Friend WithEvents CokeCremeSoda As PictureBox
    Friend WithEvents Small As Label
    Friend WithEvents Large As Label
    Friend WithEvents Medium As Label
    Friend WithEvents ExtraLarge As Label
    Friend WithEvents btnMainMenu As Button
End Class
