﻿Imports Microsoft.Data.SqlClient

Public Class FreeStyleMain
    Dim Size As Integer
    Dim Product(3) As String
    Dim CCORF As Integer = 34
    Dim CCCF As Integer = 34
    Dim CCCVF As Integer = 34
    Dim CCLEF As Integer = 34
    Dim CCLIF As Integer = 34
    Dim CCOF As Integer = 34
    Dim CCOVF As Integer = 34
    Dim CCRF As Integer = 34
    Dim CCVF As Integer = 34
    Dim CCCSF As Integer = 34
    Dim CO2 As Integer = 170
    Dim number As Integer = 0
    Dim Amounts(10) As Integer

    Private Sub Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CocaCola.BackColor = Color.White
        CokeCherry.BackColor = Color.White
        CokeCherryVanilla.BackColor = Color.White
        CokeLime.BackColor = Color.White
        CokeLemon.BackColor = Color.White
        CokeRaspberry.BackColor = Color.White
        CokeOrange.BackColor = Color.White
        CokeOrangeVanilla.BackColor = Color.White
        CokeCremeSoda.BackColor = Color.White
        CokeVanilla.BackColor = Color.White
        Small.BackColor = Color.White
        Medium.BackColor = Color.White
        Large.BackColor = Color.White
        ExtraLarge.BackColor = Color.White
    End Sub

    Private Sub btnMainMenu_Click(sender As Object, e As EventArgs) Handles btnMainMenu.Click
        CocaCola.BackColor = Color.White
        CokeCherry.BackColor = Color.White
        CokeCherryVanilla.BackColor = Color.White
        CokeLime.BackColor = Color.White
        CokeLemon.BackColor = Color.White
        CokeRaspberry.BackColor = Color.White
        CokeOrange.BackColor = Color.White
        CokeOrangeVanilla.BackColor = Color.White
        CokeCremeSoda.BackColor = Color.White
        CokeVanilla.BackColor = Color.White

        Small.BackColor = Color.White
        Medium.BackColor = Color.White
        Large.BackColor = Color.White
        ExtraLarge.BackColor = Color.White

        number = 0
        Array.Clear(Product, 0, Product.Length)
        Size = 0
    End Sub

    Private Sub CocaCola_Click(sender As Object, e As EventArgs) Handles CocaCola.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Coca-Cola Original"
            number = number + 1
        End If

        CocaCola.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeCherry_Click(sender As Object, e As EventArgs) Handles CokeCherry.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Cherry Coke"
            number = number + 1
        End If

        CokeCherry.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeCherryVanilla_Click(sender As Object, e As EventArgs) Handles CokeCherryVanilla.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Cherry Vanilla Coke"
            number = number + 1
        End If

        CokeCherryVanilla.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeLemon_Click(sender As Object, e As EventArgs) Handles CokeLemon.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Lemon Coke"
            number = number + 1
        End If

        CokeLemon.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeLime_Click(sender As Object, e As EventArgs) Handles CokeLime.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Lime Coke"
            number = number + 1
        End If

        CokeLime.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeOrange_Click(sender As Object, e As EventArgs) Handles CokeOrange.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Orange Coke"
            number = number + 1
        End If

        CokeOrange.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeOrangeVanilla_Click(sender As Object, e As EventArgs) Handles CokeOrangeVanilla.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Orange Vanilla Coke"
            number = number + 1
        End If

        CokeOrangeVanilla.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeRaspberry_Click(sender As Object, e As EventArgs) Handles CokeRaspberry.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Raspberry Coke"
            number = number + 1
        End If

        CokeRaspberry.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeVanilla_Click(sender As Object, e As EventArgs) Handles CokeVanilla.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Vanilla Coke"
            number = number + 1
        End If

        CokeVanilla.BackColor = Color.SlateGray
    End Sub

    Private Sub CokeCremeSoda_Click(sender As Object, e As EventArgs) Handles CokeCremeSoda.Click
        If number = 3 Then
            MsgBox("Cannot have more than 3 flavors",, " ")
            Return
        End If
        If number < 3 Then
            Product(number) = "Creme Soda Coke"
            number = number + 1
        End If

        CokeCremeSoda.BackColor = Color.SlateGray
    End Sub

    Private Sub Small_Click(sender As Object, e As EventArgs) Handles Small.Click
        Size = 8

        Small.BackColor = Color.SlateGray
        Medium.BackColor = Color.White
        Large.BackColor = Color.White
        ExtraLarge.BackColor = Color.White
    End Sub

    Private Sub Medium_Click(sender As Object, e As EventArgs) Handles Medium.Click
        Size = 16

        Small.BackColor = Color.White
        Medium.BackColor = Color.SlateGray
        Large.BackColor = Color.White
        ExtraLarge.BackColor = Color.White
    End Sub

    Private Sub Large_Click(sender As Object, e As EventArgs) Handles Large.Click
        Size = 24

        Small.BackColor = Color.White
        Medium.BackColor = Color.White
        Large.BackColor = Color.SlateGray
        ExtraLarge.BackColor = Color.White
    End Sub

    Private Sub ExtraLarge_Click(sender As Object, e As EventArgs) Handles ExtraLarge.Click
        Size = 32

        Small.BackColor = Color.White
        Medium.BackColor = Color.White
        Large.BackColor = Color.White
        ExtraLarge.BackColor = Color.SlateGray
    End Sub
    Private Sub btnMixDis_Click(sender As Object, e As EventArgs) Handles btnMixDis.Click
        Dim answer As Integer
        Dim number2 As Integer = 0

        If Size = 0 Then
            MsgBox("You must pick a size.",, " ")
            Return
        End If

        If number = 1 Then
            answer = MsgBox("Do you want to dispense " & Size & "oz" & " " & Product(0) & "?", vbQuestion + vbYesNo + vbDefaultButton2, "")
            If answer = vbYes Then
                MsgBox("Dispensing: " & Size & " " & Product(0),, " ")
            Else
                MsgBox("Canceling",, " ")
                Return
            End If
        End If
        If number = 2 Then
            answer = MsgBox("Do you want to dispense " & Size & "oz" & " " & Product(0) & ", " & Product(1) & "?", vbQuestion + vbYesNo + vbDefaultButton2, "")
            If answer = vbYes Then
                MsgBox("Dispensing: " & Size & " " & Product(0) & ", " & Product(1),, " ")
            Else
                MsgBox("Canceling",, " ")
                Return
            End If
        End If
        If number = 3 Then
            answer = MsgBox("Do you want to dispense " & Size & "oz" & " " & Product(0) & ", " & Product(1) & ", " & Product(2) & "?", vbQuestion + vbYesNo + vbDefaultButton2, "")
            If answer = vbYes Then
                MsgBox("Dispensing: " & Size & "oz" & " " & Product(0) & ", " & Product(1) & ", " & Product(2),, " ")
            Else
                MsgBox("Canceling",, " ")
                Return
            End If
        End If

        If number = 1 Then
            number2 = 2
        End If
        If number = 2 Then
            number2 = 4
        End If
        If number = 3 Then
            number2 = 8
        End If

        Dim pro As Integer
        For pro = 0 To 3
            If Product(pro) = "Coca-Cola Original" Then
                CCORF = CCORF - (Size / number2)
                If CCORF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Cherry Coke" Then
                CCCF = CCCF - (Size / number2)
                If CCCF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Cherry Vanilla Coke" Then
                CCCVF = CCCVF - (Size / number2)
                If CCCVF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Lemon Coke" Then
                CCLEF = CCLEF - (Size / number2)
                If CCLEF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Lime Coke" Then
                CCLIF = CCLIF - (Size / number2)
                If CCLIF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Orange Coke" Then
                CCOF = CCOF - (Size / number2)
                If CCOF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Orange Vanilla Coke" Then
                CCOVF = CCOVF - (Size / number2)
                If CCOVF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Raspberry Coke" Then
                CCRF = CCRF - (Size / number2)
                If CCRF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Vanilla Coke" Then
                CCVF = CCVF - (Size / number2)
                If CCVF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
            If Product(pro) = "Creme Soda Coke" Then
                CCCSF = CCCSF - (Size / number2)
                If CCCSF < 12 Then
                    MsgBox("Syrup is getting low. Order more!",, " ")
                End If
            End If
        Next
        CO2 = CO2 - (Size / 2)

        If CO2 < 54 Then
            MsgBox("CO2 is getting low. Order more!",, " ")
        End If
    End Sub

    Private Sub btnSyrupLvl_Click(sender As Object, e As EventArgs) Handles btnSyrupLvl.Click
        MsgBox(
        "Coka-Cola Original: " & CCORF & vbCrLf &
        "Cherry Coke: " & CCCF & vbCrLf &
        "Cherry Vanilla Coke: " & CCCVF & vbCrLf &
        "Lemon Coke: " & CCLEF & vbCrLf &
        "Lime Coke: " & CCLIF & vbCrLf &
        "Orange Coke: " & CCOF & vbCrLf &
        "Orange Vanilla Coke: " & CCOVF & vbCrLf &
        "Raspberry Coke: " & CCRF & vbCrLf &
        "Vanilla Coke: " & CCVF & vbCrLf &
        "Creme Soda Coke: " & CCCSF & vbCrLf &
        vbCrLf &
        "CO2: " & CO2,, " ")
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class
